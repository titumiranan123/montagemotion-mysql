export interface ITestimonial {
  _id: string;
  thumnail: string;
  name: string;
  designation: string;
  message: string;
}
