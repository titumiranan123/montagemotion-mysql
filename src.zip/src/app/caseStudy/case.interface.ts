export interface ICase {
  _id: string;
  thumbnail: string;
  title: string;
  category: string;
  description: string;
}
