export interface IPostwork {
  _id: string;
  title: string;
  thumbnail: string;
  category: string;
  video_category?: string;
  video_link: string;
  description: string;
}
