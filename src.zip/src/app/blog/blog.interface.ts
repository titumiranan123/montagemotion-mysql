export interface IBlog {
  _id: string;
  thumbnail: string;
  category: string;
  title: string;
  description: string;
}
