export interface IMember {
  _id: string;
  name: string;
  thumnail: string;
  designation: string;
}
