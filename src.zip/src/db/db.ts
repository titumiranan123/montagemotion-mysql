import mysql from "mysql2";
export const db = mysql.createConnection({
  host: "103.29.180.66",
  user: "montagem_montagemotion123",
  password: "725RA38et%",
  database: "montagem_MontageMotion",
});
db.connect((err) => {
  if (err) {
    console.log(` Error connecting to the database : ${err}`);
    return;
  }
  console.log("Connect to the MySQL database.");
});

// Function to handle reconnection
const handleDisconnect = () => {
  db.connect((err) => {
    if (err) {
      console.error(`Error reconnecting to the database: ${err.message}`);
      setTimeout(handleDisconnect, 2000);
    } else {
      console.log("Reconnected to the MySQL database.");
    }
  });
};

// Handle connection errors and reconnect
db.on("error", (err) => {
  console.error(`Database error: ${err.message}`);
  if (err.code === "PROTOCOL_CONNECTION_LOST") {
    handleDisconnect();
  } else {
    throw err;
  }
});

export default db;
