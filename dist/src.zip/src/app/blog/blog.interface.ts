export interface IBlog {
  _id: string;
  thumnail: string;
  category: string;
  title: string;
  description: string;
}
