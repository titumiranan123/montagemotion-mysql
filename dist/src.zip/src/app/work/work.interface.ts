export interface IPostwork {
  _id: string;
  title: string;
  thumnail: string;
  category: string;
  video_category?: string;
  video_link: string;
  description: string;
}
