interface IIntro {
  _id: string;
  video_link: string;
  thumnail: string;
}
